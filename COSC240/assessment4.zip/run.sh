#!/bin/bash

gcc -g -o divide divide.c && ./divide
