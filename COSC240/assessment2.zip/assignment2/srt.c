/*
 * An implementation of SRT scheduling.
 * Author: Tully McDonald (tmcdon26@myune.edu.au)
 */

/* The process details we're interested in for the FCFS algorithm.*/
typedef struct srt_process {
  unsigned int pid;
  unsigned int processing_time;
  unsigned int arrival_time;
  unsigned int processed_time;
  unsigned int remaining_time;
  struct srt_process *next_process;
} srt_process;

/* The list of all processes we know about.*/
srt_process process_list = {0, 0, 0, 0, 0, NULL};

/*
 * Adds the given process to the ready queue, indicating it is ready to be scheduled.
 * Keeps a list of all processes, sorted by arrival time, then pid.
 * parameters:
 *   process - the process to add to the ready queue
 */
void add_to_ready_queue(const process_initial process) {
  // Construct the new srt_process
  srt_process *new_process = malloc(sizeof(srt_process));
  new_process->pid = process.pid;
  new_process->processing_time = process.processing_time;
  new_process->arrival_time = process.arrival_time;
  new_process->processed_time = 0;
  new_process->remaining_time = process.processing_time;
  new_process->next_process = NULL;

  // Determine where in the queue it should be added
  srt_process *end = &process_list;

  // Skip past proceses with with a smaller remaining time
  while(end->next_process && end->next_process->remaining_time < new_process->remaining_time) {
    end = end->next_process;
  }

  // Skip past processes with the same remaining time and a smaller PID
  while (end->next_process && end->next_process->remaining_time == new_process->remaining_time && end->next_process->pid < new_process->pid) {
    end = end->next_process;
  }

  // Add new process to the queue in the correct location
  new_process->next_process = end->next_process;
  end->next_process = new_process;
}

/*
 * Determines the next process to the scheduled.
 * Implementes srt, meaning it will select the process with the shortest remaining time
 * that has not yet completed.
 * If two processes have the same arrival time, it will select the one with the lowest PID first.
 * returns:
 *   The PID of the process to be scheduled next, or 0 if no process should be scheduled
 */
unsigned int get_next_scheduled_process() {
  srt_process *node = &process_list;
  srt_process *shortest = &process_list;

  int shortestRemain = shortest->processing_time - shortest->processed_time;
  int nextRemain = node->next_process->processing_time - node->next_process->processed_time;

  // While there are still processes to check
  while (node->next_process) {
    srt_process *next = node->next_process;

    if (shortest->pid == 0) { // First in queue
      shortest = node->next_process;
      continue;
    } else if (next->remaining_time == 0) { // Process is complete, removing
      node->next_process = next->next_process;
      free(next);
      continue;
    } else if (shortestRemain > nextRemain) { // Next is shorter, replace shortest
      shortest = node->next_process;
    } else  if (shortestRemain == nextRemain) { // If remaining time is equal, choose smaller pid
      if (next->pid < shortest->pid) {
        shortest = node->next_process;
      }
    }

    // Move to the next process
    node = node->next_process;
  }

    if (shortest == &process_list) { // Nothing found in queue
     return 0;
    } else {
      shortest->processed_time++;
      shortest->remaining_time--;
      return shortest->pid;
    }
}