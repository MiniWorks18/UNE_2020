/*
 * An implementation of Round-robin scheduling.
 * Author: Tully McDonald (tmcdon26@myune.edu.au)
 */

/* The process details we're interested in for a exponential feedback algorithm.*/
typedef struct exp_process {
  unsigned int pid;
  unsigned int processing_time;
  unsigned int arrival_time;
  unsigned int processed_time;
  struct exp_process *next_process;
} exp_process;

/* The list of all processes we know about.*/
exp_process q_one = {0, 0, 0, 0, NULL};

unsigned int quantum = 0;
unsigned int numOfQueues = 1;
exp_process *inProgress = &q_one;
exp_process *currentList = &q_one;
exp_process *queues[] = {&q_one}; 

/*
 * Adds the given process to the ready queue, indicating it is ready to be scheduled.
 * Keeps a list of all processes, sorted by arrival time, then pid.
 * parameters:
 *   process - the process to add to the ready queue
 */
void add_to_ready_queue(const process_initial process) {
  // Construct the new exp_process
  exp_process *new_process = malloc(sizeof(exp_process));
  new_process->pid = process.pid;
  new_process->processing_time = process.processing_time;
  new_process->arrival_time = process.arrival_time;
  new_process->processed_time = 0;
  new_process->next_process = NULL;

  // Determine where in the queue it should be added
  exp_process *end = &q_one;
  // Skip past processes with an earlier arrival time
  while (end->next_process && end->next_process->arrival_time < new_process->arrival_time) {
    end = end->next_process;
  }
  // Skip past processes with the same arrival time but an earlier PID
  while (end->next_process && end->next_process->arrival_time == new_process->arrival_time && end->next_process->pid < new_process->pid) {
    end = end->next_process;
  }
  // Add new process to the queue in the correct location
  new_process->next_process = end->next_process;
  end->next_process = new_process;
}


// Abstract setup for next process
void setupNextProcess(exp_process *list, unsigned int quant) {
  // Iterate processed time
  list->next_process->processed_time++;
  // Reset quantum to ready
  quantum = quant;
  // Take first process in queue one
  inProgress = list->next_process;
  // Current list is queue one
  currentList = list;
}


/*
 * Determines the next process to be scheduled.
 * Checks current running state, selects next process depending on if a process is currently running.
 * Selects the process at the front.
 */
unsigned int get_next_scheduled_process() {
  // If a process is still in it's quantum period, select it to run
  if (quantum > 1) {
    // Only do this if process still needs CPU time
    if (inProgress->processing_time - inProgress->processed_time != 0) { 
      inProgress->processed_time++;
      quantum--;
      return inProgress->pid;
    }
  }
      
  /*
   * Manages queue transitions.
   * Check if inProgress is empty, if it is, continue, if it isn't, then: 
   * Pull the process out of it's place in the queue and either delete it
   * or move it to it's next position.
   */
  if (inProgress->pid != 0) {
    // Pulls process out of it's place in queue
    if (inProgress->next_process) {
      currentList->next_process = inProgress->next_process;
      inProgress->next_process = NULL;
    } else {
      currentList->next_process = NULL;
    }

    exp_process *nextPos = queues[numOfQueues-1];

    // If process complete, remove. Else move process to next position in queues
    if (inProgress->processing_time - inProgress->processed_time == 0) {
      free(inProgress);
    } else { 
      // Find end of selected queue
      while(nextPos->next_process) {
        nextPos = nextPos->next_process;
      }
      nextPos->next_process = inProgress;
    }
  }
  // Manages picking next from queues.
  for (int i = 0; i < numOfQueues; i++) {
    if (queues[i]->next_process) {
      setupNextProcess(queues[i], 3);
      break;
    }
  }
  return inProgress->pid;
}