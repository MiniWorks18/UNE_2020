package cosc250.roboScala

import java.awt.Color
import akka.actor.Actor
import scala.util.Random

class WallPatroler extends Actor {

  // Unique name
  val name = s"WallPatroler ${Random.alphanumeric.take(4).mkString}"

  // As soon as the tank is created, register it
  Main.gameActor ! Register(name, Color.orange)

  def receive:PartialFunction[Any, Unit] = {
    case TankState(me) =>
      Main.gameActor ! FullSpeedAhead
      if (me.energy >= Tank.startingEnergy) Main.gameActor ! RadarPing
      // Checking next frame position to keep tank inside border
      val newPos = me.position + Vec2.fromRTheta(me.velocity, me.facing)
      if (!GameState.inBounds(newPos)) {
        Main.gameActor ! TurnClockwise
      }

      val angle = angleToMid(me.position)
      val facing = me.turretFacing*180/Math.PI
      // Chooses which way the turret should be turning to face the middle
      if (angle > 10) { // Buffer around 360 degree transition to 0 degrees
        if (angle - facing < facing - angle) {Main.gameActor ! TurretAnticlockwise} else {
          Main.gameActor ! TurretClockwise
        }
      }
    case RadarResult(me, seenTanks) =>
      seenTanks.foreach(t => if (t.isAlive) sender() ! Fire)
  }

  // Finds the angle from the tank to the middle of the frame
  def angleToMid(pos:Vec2):Double = {
    // Distance between tank and mid
    val dist = Vec2(pos.x-GameState.width/2, pos.y-GameState.height/2)
    var angle = 0.0
    // Using inverse tangent to find angle with given x and y
    if (dist.x > 0 && dist.y > 0 || dist.x < 0 && dist.y < 0) {
      angle = Math.atan(Math.abs(dist.y)/Math.abs(dist.x))*180/Math.PI
    } else {
      angle = Math.atan(Math.abs(dist.x)/Math.abs(dist.y)) * 180 / Math.PI
    }
    if (dist.x > 0 && dist.y < 0) {angle+=90} // bottom right quadrant
    if (dist.x > 0 && dist.y > 0) {angle+=180} // bottom left quadrant
    if (dist.x < 0 && dist.y > 0) {angle+=270} // top left quadrant

    angle
  }



}
