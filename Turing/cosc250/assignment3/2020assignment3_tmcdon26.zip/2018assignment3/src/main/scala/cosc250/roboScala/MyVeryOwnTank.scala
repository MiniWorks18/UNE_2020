package cosc250.roboScala

import java.awt.Color
import java.util.concurrent.Future

import akka.actor.{Actor, ActorRef}
import akka.pattern.{AskTimeoutException, ask}
import akka.util.Timeout
import akka.event.Logging

import scala.concurrent.duration._
import scala.util.Random

/**
  * ** STRATEGY **
  * Tank modes: Patrol, Attack
  * Patrol: Swing radar around searching for tanks while driving in a circle.
  * Attack: Drive towards enemy but not too close. Fire at all times when enemy is
  *         in sight. If enemy is killed, continue patrolling.*/
class MyVeryOwnTank extends Actor {

  val name = "MyVeryOwnTank "+Random.alphanumeric.take(4).mkString
  var target = Vec2(0,0)
  var attack = false
  val minApproach = 180
  val maxApproach = 200
  var coolDown = 0
  val coolDownPeriod = 100
  var patrolCooldown = 0
  var patrolCooldownPeriod = 10

  import context.dispatcher

  Main.gameActor ! Register(name, Color.green)

  def receive = {
    // Update tank state. If attacking, approach and fire, if not, switch to patrol mode.
    case TankState(me) => {
      if (me.energy >= Tank.startingEnergy) sender() ! RadarPing

      if (attack && coolDown > 0) { // If in attack mode
        // Keeps radar facing forward
        if (me.radarFacing < me.turretFacing) {Main.gameActor ! RadarClockwise}
        else Main.gameActor ! RadarAnticlockwise
        
        if (GameState.inBounds(me.position)) {
          // Keeps within approach distance of target
          if (Vec2.dist(target, me.position) > maxApproach) {Main.gameActor ! FullSpeedAhead}
          else if (Vec2.dist(target, me.position) < minApproach) {Main.gameActor ! FullReverse}
          target(target, me)
        } else { // Out of bounds
          Main.gameActor ! TurnClockwise
          Main.gameActor ! FullSpeedAhead
        }
        coolDown -= 1
      } else patrol(me)
    }

    // If not already attacking, look for other targets and engage. Otherwise switch to patrol mode
    case RadarResult(me, seenTanks) => {
      if (!attack) {
        if (seenTanks.nonEmpty) {
          seenTanks.foreach(t =>
            if (t.isAlive) {
              target = t.position // Update target position
              attack = true
              coolDown = coolDownPeriod
            } else patrol(me)
          )
        } else patrol(me)
      } else if (me.energy >= Tank.startingEnergy) sender() ! Fire
    }

    // Handles insults by asking insultsActor for the retort then sending it to the insult sender
    case Insulted(insult) => {
      import context.dispatcher
      val log = Logging(context.system, this)
      val s = sender()
      implicit val timeout:Timeout = 1.seconds
      // Log the insult to console
      log.info(s+" said: "+insult)
      for {
        response <- (Main.insultsActor ? WhatsTheRetortFor(insult)).mapTo[Retort]
      } {
        // Log the retort to console
        log.info(name+" retorted with: "+response.retort)
        // Send the retort
        s ! Retort(response.retort)
      }
    }
  }

  /** Aims turret and tank towards the baddie */
  def target(baddie:Vec2, me:Tank): Unit = {
    val dist = Vec2(me.position.x-baddie.x, me.position.y-baddie.y)
    var angle = 0.0
    val facing = me.facing*180/Math.PI

    // Decides which direction turret should turn to better aim
    if (dist.x > 0 && dist.y > 0 || dist.x < 0 && dist.y < 0) {
      angle = Math.atan(Math.abs(dist.y)/Math.abs(dist.x))*180/Math.PI
    } else {
      angle = Math.atan(Math.abs(dist.x)/Math.abs(dist.y))*180/Math.PI
    }

    // Allows for aiming beyond the limits of Tangent, adds 90 degrees per quadrant
    if (dist.x > 0 && dist.y < 0) {angle+=90}
    if (dist.x > 0 && dist.y > 0) {angle+=180}
    if (dist.x < 0 && dist.y > 0) {angle+=270}

    if (angle > 5) { // Buffer around 360 degree transition
      if (angle - facing < facing - angle) {
        Main.gameActor ! TurnAnticlockwise
      } else {
        Main.gameActor ! TurnClockwise
      }
      val turretFacing = me.turretFacing * 180 / Math.PI
      if (angle - turretFacing < turretFacing - angle) {
        Main.gameActor ! TurretAnticlockwise
      } else {
        Main.gameActor ! TurretClockwise
      }
    }
  }

  /** Patrol mode, pings radar in circles, drives in big circle */
  def patrol(me:Tank): Unit = {
    Main.gameActor ! RadarClockwise
    target = Vec2(0,0) // Setting target location to null
    attack = false // Deactivates attack mode
    Main.gameActor ! FullSpeedAhead
    if (!GameState.inBounds(me.position)) {
      Main.gameActor ! TurnAnticlockwise
    } else if (patrolCooldown == 0) {
      Main.gameActor ! TurnClockwise
      patrolCooldown = patrolCooldownPeriod
    } else {patrolCooldown -= 1}
  }
}
