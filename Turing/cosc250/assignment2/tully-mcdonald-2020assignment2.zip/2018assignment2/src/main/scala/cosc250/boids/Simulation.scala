package cosc250.boids

import scala.collection.mutable

object Simulation {

  /** Wrap width of the simulation. ie, for any Boid, 0 <= x < 640 */
  val width = 640

  /** Wrap height of the simulation. ie, for any Boid, 0 <= y < 480 */
  val height = 480

  /** How many frames of the simulation to hold */
  val frameMemory = 60

  /** How manby boids to start with in the simulation */
  val numBoids = 150

  /** When the wind is blowing, how strongly it blows */
  val windStrength = 0.03

  /** When the boids are startled, the strength of the vector that is applied to each of them */
  val startleStrength:Double = Boid.maxSpeed

  val startleFunction:Boid => Vec2 = _ => Vec2.randomDir(startleStrength)

  /** A mutable queue containing the last `frameMemory frames` */
  val queue:mutable.Queue[Seq[Boid]] = mutable.Queue.empty[Seq[Boid]]

  /** The wind -- an optional acceleration vector */
  var wind:Vec2 = Vec2(0,0)

  /** Boolean if new boid should be added next frame */
  var newBoid:Boolean = false

  /** Time left on startle period */
  var startle:Int = 0

  /** Boolean if queue should be reset next frame */
  var resetQueueBool = false

  /**
    * Sets a wind blowing at windStrength, at this angle.
    * Note that a northerly wind blows **from** the north, so we multiply the vector by -1.
    */
  def setWindDirection(theta:Double):Unit = wind = Vec2(-Math.cos(theta)*windStrength, -Math.sin(theta)*windStrength)

  /** A container that can hold a boid to add on the next frame */
  var insertBoid:Option[Boid] = None

  /**
    * A function that will run for the next frame only over each boid in the system,
    * producing an acceleration vector to add to a Boid
    */
  var oneTimeFunction:Option[Boid => Vec2] = None

  /**
    * Resets the events that should occur one time only
    */
  def resetOneTimeEvents():Unit = {
    // Delete all current boids then generate a new explosion
    queue.removeAll()
    explosionOfBoids(numBoids)
  }

  /** The current frame */
  def current = if(resetQueueBool) {
    resetQueueBool = false
    resetQueue()
  } else queue.last

  /** Generates boids in the centre of the simulation, moving at v=1 in a random direction */
  def explosionOfBoids(i:Int):Seq[Boid] = {
    val seq:mutable.Queue[Boid] = mutable.Queue.empty[Boid] // Queue of boids being generated
    // For amount i, make new boid in the middle of the screen with random velocity direction
    for (_ <- 0 to i) seq.enqueue(Boid(Vec2(width/2,height/2),Vec2.randomDir(Boid.maxSpeed)))
    seq.toSeq
  }

  /** Pushes a state into the queue */
  def pushState(boids:Seq[Boid]):Seq[Boid] = {
    queue.enqueue(boids) // Places a state on the top of the queue

    // Drops a frame from the queue if we've reached the maximum number of frames to remember
    if (queue.lengthCompare(frameMemory) > 0) queue.dequeue()
    boids
  }

  /** Called by a click to the canvas, to say that in the next frame, a boid should be inserted */
  def pushBoid(b:Boid):Unit = {
    insertBoid = Some(b)
  }

  /** Called by the Action Replay button to jump back in the memory buffer */
  def resetQueue():Seq[Boid] = {
    queue.head
  }

  /** Generate the next frame in the simulation */
  def update():Seq[Boid] = {
    val updatedSeq: mutable.Queue[Boid] = mutable.Queue.empty[Boid]
    current.foreach( i => { // For every boid, update and add to new sequence of boids to then put on the queue
      // Insert new boid into the queue
      // I played around without the if statement, but this was adding the same boid. Even when i would try
      // using insertBoid.empty it would still loop and add over and over.
      if (newBoid) {
        insertBoid.collect(b => updatedSeq.enqueue(b))
        newBoid = false
      }
      // Startle function applied here. I couldn't make this work without the cooldown 'startle'
      if (startle > 0) { // New boid same position, startFunction velocity, else just update.
        updatedSeq.enqueue(Boid(i.position, startleFunction(i)))
        startle -= 1
      } else {updatedSeq.enqueue(i.update(i.flock(current), wind))}
    })
    pushState(updatedSeq.toSeq)
    updatedSeq.toSeq
  }

}
