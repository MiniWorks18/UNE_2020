package cosc250.boids


/**
  * A boid (bird-oid). It has a position and a velocity.
  *
  *
  * https://processing.org/examples/flocking.html
  */
case class Boid(
  position:Vec2, velocity:Vec2
) {

  /**
    * Calculates an acceleration vector that will cause it to maintain a minimum
    * separation from its closest neighbours
    * This steer is limited to maxForce
    */
  def separate(others:Seq[Boid]):Vec2 = {
    var steer = Vec2(0, 0)
    var count = 0
    others.foreach(a => {
      //val vecDist = this.position-a.position
      //val dist = Math.abs(vecDist.x-vecDist.y)
      val dist = position.distance(a.position)
      //println("Distance:"+dist)
      if ((dist > 0) && (dist < Boid.desiredSeparation)) { // If too close and not itself (0)
        //println("Uh oh: "+dist)
        var diff = position - a.position
        diff = diff.normalised
        diff = diff/dist
        steer = steer+diff
        count += 1
      }
    }
    )
    if (count > 0) {
      steer = steer/count
    }

    if (steer.magnitude > 0 ) { // Steering = desired - velocity
      steer = steer.normalised
      steer = steer*Boid.maxSpeed
      steer = steer-velocity
      steer = steer.limit(Boid.maxForce)
    }
    steer
  }

  /**
    * Calculates an acceleration vector that will cause it align its direction and
    * velocity with other birds within Boid.neighbourDist
    * This alignment force is limited to maxForce
    */
  def align(others:Seq[Boid]):Vec2 = {
    var sum = Vec2(0,0)
    var steer = Vec2(0,0)
    var count = 0
    others.foreach(a => { // For each, check if boid's distance is within neighbourDist add velocity if true
      val dist = position.distance(a.position)
      if ((dist > 0) && (dist < Boid.neighBourDist)) {
        sum = sum+a.velocity
        count += 1
      }
    })
    if (count > 0) { // Calculate steering vector using sum and count
      sum = sum/count
      sum = sum.normalised
      sum = sum.limit(Boid.maxSpeed)
      steer = sum-velocity
      steer = steer.limit(Boid.maxForce)
    }
    steer
  }

  /**
    * Calculates an acceleration that will steer this boid towards the target.
    * The steer is limited to maxForce
    */
  def seek(targetPos:Vec2):Vec2 = {
    var desired:Vec2 = targetPos-position
    desired = desired.normalised
    desired = desired*Boid.maxSpeed

    var steer = desired-velocity
    steer = steer.limit(Boid.maxForce)
    steer
  }


  /**
    * Calculates an acceleration that will keep it near its neighbours and maintain
    * the flock cohesion
    */
  def cohesion(others:Seq[Boid]):Vec2 = {
    var sum = Vec2(0,0)
    var steer = Vec2(0,0)
    var count = 0
    // For each, check if within neighbourDist (would eqeal 0 if itself)
    others.foreach(a => { // For each, check if within neighbourDist add position to sum if true
      val dist = position.distance(a.position)
      if (dist > 0 && dist < Boid.neighBourDist) {
        sum += a.position
        count += 1
      }
    })
    if (count > 0) { // Calculate steering vector
      steer = sum/count
      steer = seek(steer)
    }
    steer
  }


  /**
    * Calculates a flocking acceleration that is a composite of its separation,
    * align, and cohesion acceleration vectors.
    */
  def flock(others:Seq[Boid]):Vec2 = {
    var sep = separate(others)
    var ali = align(others)
    var coh = cohesion(others)
    // Add weight to the velocities
    sep = sep*1.5
    ali = ali*1.0
    coh = coh*1.0
    // Return the sum of the velocities
    sep+coh+ali
  }

  /**
    * Produces a new Boid by adding the boid's velocity to its position, and adding
    * the acceleration vector to the boid's velocity. Note that there is no division
    * by timestep -- it's just p = p + v, and v = v + a
    *
    * Also note that we don't apply the limiting on maxForce in this function -- this is
    * so that the startle effect can dramatically perturb the birds in a way they would
    * not normally be perturbed in flight. Instead, limit maxForce in the flock function
    * (or the functions it calls)
    *
    * We do, however, limit a boid's velocity to maxSpeed in this function. But we do it
    * *before* we add the influence of the wind to the boid's velocity -- it's possible
    * to fly faster downwind than upwind.
    */
  def update(acceleration:Vec2, wind:Vec2):Boid = {
    // Updates position with velocity while running wrapX and wrapY
    val pos: Vec2 = Vec2(wrapX(position.x), wrapY(position.y)) + velocity
    var vel:Vec2 = velocity+acceleration+wind
    // Stops accelerating if at max speed
    if (vel.x > Boid.maxSpeed || vel.x < -Boid.maxSpeed) {vel = Vec2(velocity.x, vel.y)}
    if (vel.y > Boid.maxSpeed || vel.y < -Boid.maxSpeed) {vel = Vec2(vel.x, velocity.y)}
    Boid(pos, vel)
  }

  // Check for out of bounds positions, update to opposite edge of window
  def wrapX(x:Double):Double = {
    if (x > Boid.maxX) x - Boid.maxX else if (x < 0) x + Boid.maxX else x
  }

  def wrapY(y:Double):Double = {
    if (y > Boid.maxY) y - Boid.maxY else if (y < 0) y + Boid.maxY else y
  }
}

object Boid {
  /** How far apart the boids want to be */
  val desiredSeparation = 25

  /** Maximum flying velocity of a boid */
  val maxSpeed = 2

  /** maximum accelaration of a boid */
  val maxForce = 0.03

  /** Other boids within this range are considered neighbours */
  val neighBourDist = 60

  /** How long should the boids be startled for */
  val startleLength = 600

  /** Wrap width of the simulation. ie, for any Boid, 0 <= x < 640 */
  def maxX:Int = Simulation.width

  /** Wrap height of the simulation. ie, for any Boid, 0 <= y < 480 */
  def maxY:Int = Simulation.height
}


