// Window onLoad listener
window.addEventListener("load", function (e) {
    // Wait until DOM is loaded
    alert("DOM has loaded!");
});


// Add an error message to the #errors element
function addError(message) {
    var p = document.createElement("p");
    var text = document.createTextNode(message);
    p.appendChild(text);
    document.getElementById("errors").appendChild(p);
}


// Clear all error messages from the #errors element
function clearErrors(){

}


// Validate the form, returning true if valid, false otherwise
function validate(e) {
    var success = true;


    if (success) {
        alert("The information you provided is valid.");
    }
    return success;
}
