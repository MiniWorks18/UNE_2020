// Wait until the DOM is loaded, then grab a list of photos

// $(function(){



// Function to retrieve a list of photos and append them to the #student_photos element

// function loadPhotos(){



// Function to initialise the left/right photo buttons

// function initPhotoButtons(){

