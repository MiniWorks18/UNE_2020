/* On DOM Load, update the information in the right hand column */
$(function(){
    /* code here runs when DOM is loaded */

})


/**
 * Add a <li> list item to the specified HTML element
 *
 * @param {string} selector jQuery selector for the list element, e.g. <ul>, <ol>
 * @param {string} text The text to be inserted
 */
function addListItem(selector, text){
  $(selector).append($("<li>").text(text));
}


/*
 * Perform an AJAX request to get timetable information.
 * Update the timetable information in the right hand column in the callback. 
 */

// function updateTimetable(){



/*
 * Perform an AJAX request to get information on the teaching staff.
 * Update the teaching staff information in the right hand column in the callback. 
 */

// function updateStaff(){
//
