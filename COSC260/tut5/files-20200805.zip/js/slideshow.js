// jQuery onLoad function
$(function(){
  // run the changeImage function every 5000 ms
  setInterval("updateImage()", 5000);
})

