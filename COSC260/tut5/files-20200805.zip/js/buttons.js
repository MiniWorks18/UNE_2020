// jQuery onLoad: this will run once the DOM has been loaded
// This is a jQuery shortcut for document.onload()
$(function(){
    /* This will run once the DOM is loaded */
});

